# AGENTGATE Phase 5 — React Dashboard

This folder adds a React/Vite security dashboard to the unified Phase 1–4 backend. The external WORM archive remains excluded, as requested.

## Dashboard features

- Gateway connection status and API key entry (key stays in React component state; it is not saved to local storage).
- Audit event table with pagination and exact-match filters.
- ALLOW/BLOCK summary for the currently loaded page.
- HMAC audit-chain verification via `GET /v1/audit/verify`.
- JSON and CSV export using the existing API.
- Event detail drawer/modal.
- Responsive desktop and mobile layout.
- Clear handling for `401`, `403`, API unreachable, and CORS errors.

## Start the backend

Use your existing trusted server bootstrap to create the `SecurityEngine`, `FileSecurity`, and API authenticator, register the API-key user's active session, and configure `audit_readers` with the intended audit-reader identity. Then run Uvicorn against the module/object that creates the app.

The API requires trusted server-side configuration; the dashboard cannot create or elevate an audit-reader identity. Example key-map environment shape (use a real active session registered in the security store):

```bash
export AGENTGATE_API_KEYS='{"replace-with-a-secret-key":{"user_id":"admin-user","session_id":"registered-active-session"}}'
export AGENTGATE_AUDIT_KEY='replace-with-a-stable-random-secret-of-at-least-32-bytes'
export AGENTGATE_CORS_ORIGINS='http://127.0.0.1:5173,http://localhost:5173'
```

Do not commit real secrets to Git.

## Start the dashboard

Requirements: Node.js 18+ and npm.

```bash
cd frontend
npm install
cp .env.example .env
npm run dev
```

Open the Vite URL shown in the terminal (normally `http://127.0.0.1:5173`). Enter the API URL and a configured Gateway API key. The mapped identity must be in the server-side audit reader allowlist to view audit records.

Production: build static assets with `npm run build`. Configure `AGENTGATE_CORS_ORIGINS` to include only the deployed dashboard origin(s).

## API endpoints used

- `GET /health`
- `GET /v1/audit?limit=50&offset=0` with exact-match filters
- `GET /v1/audit/verify`
- `GET /v1/audit/export?format=json&limit=5000`
- `GET /v1/audit/export?format=csv&limit=5000`
- `GET /v1/audit/{event_id}`

## Phase 5 scope

This is the dashboard layer. It does not change policy decisions or bypass gateway authorization. It does not include AWS/WORM archive functionality.
